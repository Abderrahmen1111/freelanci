"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Home, Users, Briefcase, Settings, LogOut, CreditCard, Bell, HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface SidebarProps {
  userType?: "client" | "freelancer" | "admin"
}

export default function Sidebar({ userType = "client" }: SidebarProps) {
  const [isHovered, setIsHovered] = useState(false)

  const menuItems = {
    client: [
      { icon: Home, label: "Accueil", href: "/", badge: null },
      { icon: Users, label: "Freelancers", href: "/client-dashboard", badge: null },
      { icon: Briefcase, label: "Mes Projets", href: "/client-dashboard", badge: "3" },
      { icon: CreditCard, label: "Paiements", href: "/client-dashboard", badge: null },
      { icon: Bell, label: "Notifications", href: "/notifications", badge: "5" },
      { icon: Settings, label: "Paramètres", href: "/settings", badge: null },
      { icon: HelpCircle, label: "Aide", href: "/help", badge: null },
    ],
    freelancer: [
      { icon: Home, label: "Accueil", href: "/", badge: null },
      { icon: Briefcase, label: "Mes Projets", href: "/freelancer-dashboard", badge: "2" },
      { icon: Users, label: "Clients", href: "/freelancer-dashboard", badge: null },
      { icon: CreditCard, label: "Revenus", href: "/freelancer-dashboard", badge: null },
      { icon: Bell, label: "Notifications", href: "/notifications", badge: "3" },
      { icon: Settings, label: "Paramètres", href: "/settings", badge: null },
      { icon: HelpCircle, label: "Aide", href: "/help", badge: null },
    ],
    admin: [
      { icon: Home, label: "Dashboard", href: "/admin-dashboard", badge: null },
      { icon: Users, label: "Utilisateurs", href: "/admin-dashboard", badge: "1.2k" },
      { icon: Briefcase, label: "Projets", href: "/admin-dashboard", badge: "456" },
      { icon: CreditCard, label: "Paiements", href: "/admin-dashboard", badge: null },
      { icon: Bell, label: "Signalements", href: "/admin-dashboard", badge: "23" },
      { icon: Settings, label: "Paramètres", href: "/settings", badge: null },
    ],
  }

  const currentMenuItems = menuItems[userType]

  return (
    <>
      {/* Hover Zone */}
      <div className="fixed left-0 top-0 w-4 h-full z-40" onMouseEnter={() => setIsHovered(true)} />

      <AnimatePresence>
        {isHovered && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/20 z-40"
              onClick={() => setIsHovered(false)}
            />

            {/* Sidebar */}
            <motion.div
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 h-full w-80 bg-white shadow-2xl z-50 flex flex-col"
              onMouseLeave={() => setIsHovered(false)}
            >
              {/* Header */}
              <motion.div
                className="p-6 border-b bg-gradient-to-r from-red-500 to-green-500"
                animate={{
                  background: [
                    "linear-gradient(90deg, #ef4444, #22c55e)",
                    "linear-gradient(90deg, #22c55e, #3b82f6)",
                    "linear-gradient(90deg, #3b82f6, #ef4444)",
                    "linear-gradient(90deg, #ef4444, #22c55e)",
                  ],
                }}
                transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY }}
              >
                <div className="flex items-center space-x-3">
                  <motion.div
                    className="w-10 h-10 bg-white rounded-lg flex items-center justify-center"
                    whileHover={{
                      scale: 1.2,
                      rotate: 360,
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    <motion.span
                      className="text-red-500 font-bold text-sm"
                      animate={{
                        scale: [1, 1.1, 1],
                        rotate: [0, 5, -5, 0],
                      }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                    >
                      Fi
                    </motion.span>
                  </motion.div>
                  <div className="text-white">
                    <motion.h2
                      className="font-bold text-lg"
                      animate={{ opacity: [1, 0.8, 1] }}
                      transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
                    >
                      Freelancii.tn
                    </motion.h2>
                    <p className="text-sm opacity-90">
                      {userType === "admin" ? "Administration" : userType === "freelancer" ? "Freelancer" : "Client"}
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* User Profile */}
              <div className="p-6 border-b">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src="/placeholder.svg?height=48&width=48" />
                    <AvatarFallback>
                      {userType === "admin" ? "AD" : userType === "freelancer" ? "FL" : "CL"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800">
                      {userType === "admin"
                        ? "Admin User"
                        : userType === "freelancer"
                          ? "Ahmed Ben Ali"
                          : "Mohamed Sassi"}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {userType === "admin"
                        ? "Administrateur"
                        : userType === "freelancer"
                          ? "Développeur Full Stack"
                          : "Entrepreneur"}
                    </p>
                  </div>
                </div>
                {userType !== "admin" && (
                  <Link href="/subscription">
                    <Button size="sm" className="w-full mt-3 bg-gradient-to-r from-blue-600 to-green-600">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Abonnement Pro
                    </Button>
                  </Link>
                )}
              </div>

              {/* Navigation */}
              <nav className="flex-1 p-4">
                <div className="space-y-2">
                  {currentMenuItems.map((item, index) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <Link href={item.href}>
                        <Button variant="ghost" className="w-full justify-start h-12 hover:bg-gray-100 group">
                          <item.icon className="h-5 w-5 mr-3 text-gray-600 group-hover:text-blue-600 transition-colors" />
                          <span className="flex-1 text-left">{item.label}</span>
                          {item.badge && (
                            <Badge variant="secondary" className="ml-2">
                              {item.badge}
                            </Badge>
                          )}
                        </Button>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </nav>

              {/* Footer */}
              <div className="p-4 border-t">
                <Button variant="ghost" className="w-full justify-start text-red-600 hover:bg-red-50">
                  <LogOut className="h-5 w-5 mr-3" />
                  Déconnexion
                </Button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
